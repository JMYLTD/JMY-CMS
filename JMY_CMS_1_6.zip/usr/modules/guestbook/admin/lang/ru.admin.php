<?php

/**
* @name        JMY CMS
* @link        http://jmy.su/
* @copyright   Copyright (C) 2012-2014 JMY LTD
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      Komarov Ivan
* @edit 	   03.02.2015
*/

define('_G_GUESTBOOK', 'Гостевая книга');
define('_G_EDIT', 'Редактирование');
define('_G_COM', 'Комментарий');
define('_G_REPLY', 'Ответ');
define('_G_REPLY_EDIT', 'Редактировать ответ');
define('_G_REPLY_UPDATE', 'Ответ успешно обнолён!');
define('_G_DEL', 'Удалить комментарий');
define('_G_EMPTY', 'Гостевая книга пуста!');
define('_G_INFO', 'Информация о комментарии');
define('_G_TEXT', 'Текст комментария');

