<?php

/**
* @name        JMY CMS
* @link        http://jmy.su/
* @copyright   Copyright (C) 2012-2014 JMY LTD
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      Komarov Ivan
*/

$core->loadModLang('pm');
$linkIcon['pm'] = '<img src="media/other/add_pm.png" border="0" style="vertical-align:middle" />';
$link['pm'] = '<a href="pm/write" title="' . _ADD_PM . '">' . _ADD_PM . '</a>';