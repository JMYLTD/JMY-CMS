<?php

/**
* @name        JMY CMS
* @link        http://jmy.su/
* @copyright   Copyright (C) 2012-2014 JMY LTD
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      Komarov Ivan
*/

define('_FEEDBACK', 'Обратная связь');
define('_SENDINGMESS', 'Отправка сообщения');
define('_SENDOK', 'Ваше сообщение отправлено');
define('_SENDFALSE', 'Не заполнены обязательные поля формы, вернитесь назад и заполните недостающие поля!');
define('_CAPTCHAFALSE', 'Код каптчи введён неверно!');