<?php

/**
* @name        JMY CMS
* @link        http://jmy.su/
* @copyright   Copyright (C) 2012-2014 JMY LTD
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      Komarov Ivan
*/

define('_APFEEDBACK', 'Обратная связь');
define('_APFEEDBACK_MAIN', 'Основные настройки');
define('_APFEEDBACK_MAIN_ALLOW_ATTACHT', 'Разрешить аттачи');
define('_APFEEDBACK_MAIN_ALLOW_ATTACHD', 'Разрешить в обратной связи заливать файлы:');
define('_APFEEDBACK_MAIN_FORMATST', 'Допустимые форматы');
define('_APFEEDBACK_MAIN_FORMATSD', 'Форматы, разрешённые для загрузки');
define('_APFEEDBACK_MAIN_FILE_SIZET', 'Размер файла');
define('_APFEEDBACK_MAIN_FILE_SIZED', 'Максимально допустимый размер файла');