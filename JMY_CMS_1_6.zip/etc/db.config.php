<?php
if (!defined('ACCESS')) 
{
    header('Location: /');
    exit;
}


$dbhost = '';
$dbuser = '';
$dbpass = '';
$dbname = '';

$prefix = 'JMY';
$user_prefix = 'JMY';
$user_db = 'jmy';

