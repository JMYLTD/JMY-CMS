<?php
if (!defined('ACCESS')) 
{
    header('Location: /');
    exit;
}


$dbhost = 'localhost';
$dbuser = '';
$dbpass = '';
$dbname = '';

$prefix = '';
$user_prefix = 'JMY';
$user_db = 'jmy';

