<?php
define('_NEWS', 'Новости');
define('_TAGS_ALL', 'Тэгов всего');
define('_NEWSNOTFOUND', 'Ни одной новости не найдено.');
define('_MORE', 'Читать далее');
define('_EDIT_NEWS', 'Редактировать новость');
define('_DELETE_NEWS', 'Удалить новость');
define('_ADD_NEWS', 'Добавить новость');
define('_RELATED_NEWS', 'Похожие новости');
define('_NEWS_COMMENTS_OFF', 'Комментирование данной новости отключено');
